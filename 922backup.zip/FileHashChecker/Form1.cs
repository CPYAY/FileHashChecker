using Microsoft.VisualBasic.Devices;
using System.Security.Cryptography;
using System.Text;

namespace FileHashChecker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSelectFile_Click(object sender, EventArgs e)
        {
            var result = openFileDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {
                textBox1.Text = openFileDialog1.FileName;
            }
        }

        private async void BtnCalcMD5_Click(object sender, EventArgs e)
        {
            string filename = textBox1.Text;
            if (File.Exists(filename) ){
                byte[] md5HashBytes = await Task.Run(() => ComputeMd5Hash(filename));

                textBox2.Text = ToHexadecimal(md5HashBytes);
            }
            else
            {
                textBox2.Text = "invalid";
            }
        }

        private byte[] ComputeMd5Hash(string filename)
        {
            byte[] result = null;
            using (MD5 md5 = MD5.Create())
            {
                int bufferSize = 10 * 1024 * 1024; //10MB
                using (var stream = new BufferedStream(File.OpenRead(filename), bufferSize))
                {
                    result = md5.ComputeHash(stream);
                }
            }
            return result;
        }
        static string ToHexadecimal(byte[] source)
        {
            if (source == null) return string.Empty;
            StringBuilder sb = new StringBuilder();
            foreach (byte b in source)
            {
                sb.Append(b.ToString("X2")); // print bytes as Hexadecimal
            }
            return sb.ToString();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}